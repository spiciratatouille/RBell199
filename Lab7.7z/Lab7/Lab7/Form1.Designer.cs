﻿namespace Lab7
{
    partial class Lab7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.futureValLbl = new System.Windows.Forms.Label();
            this.intRateLbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.presValLbl = new System.Windows.Forms.Label();
            this.presValOutput = new System.Windows.Forms.Label();
            this.futureValInput = new System.Windows.Forms.TextBox();
            this.intRateInput = new System.Windows.Forms.TextBox();
            this.numYearsInput = new System.Windows.Forms.TextBox();
            this.CalcBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // futureValLbl
            // 
            this.futureValLbl.AutoSize = true;
            this.futureValLbl.Location = new System.Drawing.Point(12, 30);
            this.futureValLbl.Name = "futureValLbl";
            this.futureValLbl.Size = new System.Drawing.Size(105, 20);
            this.futureValLbl.TabIndex = 0;
            this.futureValLbl.Text = "Future Value:";
            // 
            // intRateLbl
            // 
            this.intRateLbl.AutoSize = true;
            this.intRateLbl.Location = new System.Drawing.Point(12, 77);
            this.intRateLbl.Name = "intRateLbl";
            this.intRateLbl.Size = new System.Drawing.Size(161, 20);
            this.intRateLbl.TabIndex = 1;
            this.intRateLbl.Text = "Annual Interest Rate:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number of Years:";
            // 
            // presValLbl
            // 
            this.presValLbl.AutoSize = true;
            this.presValLbl.Location = new System.Drawing.Point(12, 200);
            this.presValLbl.Name = "presValLbl";
            this.presValLbl.Size = new System.Drawing.Size(113, 20);
            this.presValLbl.TabIndex = 3;
            this.presValLbl.Text = "Present Value:";
            // 
            // presValOutput
            // 
            this.presValOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.presValOutput.Location = new System.Drawing.Point(217, 195);
            this.presValOutput.Name = "presValOutput";
            this.presValOutput.Size = new System.Drawing.Size(122, 25);
            this.presValOutput.TabIndex = 4;
            // 
            // futureValInput
            // 
            this.futureValInput.Location = new System.Drawing.Point(217, 24);
            this.futureValInput.Name = "futureValInput";
            this.futureValInput.Size = new System.Drawing.Size(122, 26);
            this.futureValInput.TabIndex = 5;
            // 
            // intRateInput
            // 
            this.intRateInput.Location = new System.Drawing.Point(217, 74);
            this.intRateInput.Name = "intRateInput";
            this.intRateInput.Size = new System.Drawing.Size(122, 26);
            this.intRateInput.TabIndex = 6;
            // 
            // numYearsInput
            // 
            this.numYearsInput.Location = new System.Drawing.Point(217, 137);
            this.numYearsInput.Name = "numYearsInput";
            this.numYearsInput.Size = new System.Drawing.Size(122, 26);
            this.numYearsInput.TabIndex = 7;
            // 
            // CalcBtn
            // 
            this.CalcBtn.Location = new System.Drawing.Point(217, 254);
            this.CalcBtn.Name = "CalcBtn";
            this.CalcBtn.Size = new System.Drawing.Size(100, 32);
            this.CalcBtn.TabIndex = 8;
            this.CalcBtn.Text = "Calculate";
            this.CalcBtn.UseVisualStyleBackColor = true;
            this.CalcBtn.Click += new System.EventHandler(this.CalcBtn_Click);
            // 
            // Lab7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 320);
            this.Controls.Add(this.CalcBtn);
            this.Controls.Add(this.numYearsInput);
            this.Controls.Add(this.intRateInput);
            this.Controls.Add(this.futureValInput);
            this.Controls.Add(this.presValOutput);
            this.Controls.Add(this.presValLbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.intRateLbl);
            this.Controls.Add(this.futureValLbl);
            this.Name = "Lab7";
            this.Text = "Lab 7";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label futureValLbl;
        private System.Windows.Forms.Label intRateLbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label presValLbl;
        private System.Windows.Forms.Label presValOutput;
        private System.Windows.Forms.TextBox futureValInput;
        private System.Windows.Forms.TextBox intRateInput;
        private System.Windows.Forms.TextBox numYearsInput;
        private System.Windows.Forms.Button CalcBtn;
    }
}

