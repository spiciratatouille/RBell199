﻿// ID: J1559
// Lab 7
// Due: 11/10/2019
// CIS199-01
// This program calculates the amount necessary to invest today to reach a user entered future value
// under user entered conditions of interest rate and number of years
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace Lab7
{
    public partial class Lab7 : Form
    {
        public Lab7()
        {
            InitializeComponent();
        }
        // activates once user clicks the calculate button
        // Precondition: all fields must have valid, positive inputs- future value and int rate must be doubles, num of years must be an int
        // Postcondition: outputs the necessary current value that is calculated by the CalcPresentValue method to the label
        private void CalcBtn_Click(object sender, EventArgs e)
        {
            double futureValue; // goal value
            double intRate; // annual interest rate
            int numYears; // number of years
            double presentValue; // value needed to reach the goal value

            // inputting user entered data
            futureValue = double.Parse(futureValInput.Text);
            intRate = double.Parse(intRateInput.Text);
            numYears = int.Parse(numYearsInput.Text);

            // call method and output to label
            presentValue = CalcPresentValue(futureValue, intRate, numYears);
            presValOutput.Text = ($"{presentValue:C2}");

            
        }
        // calculates the present value needed to reach goal value once method is called
        //Precondition: all values must be valid and positive
        //Postcondition: method will return the necessary present value to achieve the user inputted future value given inputted num of years and interest rate
        public static double CalcPresentValue(double futureValue, double intRate, int numYears)
        {
            double presentValue; //the present value to be invested
            double years = (double)numYears; //convert int years to double for calculation
            presentValue = futureValue / Math.Pow((1 + intRate), numYears); //arithmetic
            return presentValue;
        }
    }
}
