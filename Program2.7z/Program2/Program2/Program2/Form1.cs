﻿// Grading ID: J1559
// Program 2
// Due: 10/16/2019
// CIS199-01
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace Program2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }
        // activates once user clicks button
        private void CompBtn_Click(object sender, EventArgs e)
        {
            const int SENIOR = 90; // cutoff for senior hours
            const int JUNIOR = 60; // cutoff for junior hours
            const int SOPH = 30; // cutoff for sophomore hours
            const int FRESH = 0; // cutoff for freshman hours
            char Name; // first letter of last name
            float Hrs; // number of credit hours

            //Dates to register

            string Date1 = "MONDAY, NOV. 4"; // first date slot
            string Date2 = "TUESDAY, NOV. 5"; // second date slot
            string Date3 = "WEDNESDAY, NOV. 6"; // third date slot
            string Date4 = "THURSDAY, NOV. 7"; // fourth date slot
            string Date5 = "FRIDAY, NOV. 8"; // fifth date slot
            string Date6 = "MONDAY, NOV. 11"; // sixth date slot

            //Times to register

            string Time1 = "8:30 AM"; // first time slot
            string Time2 = "10:00 AM"; // second time slot
            string Time3 = "11:30 AM"; // third time slot
            string Time4 = "2:00 PM"; // fourth time slot
            string Time5 = "4:00 PM"; // fifth time slot

            Name = Char.Parse(LastInInput.Text); // input last initial from text box
            Name = char.ToLower(Name); // convert last initial to lowercase

            Hrs = float.Parse(CreditHrsInput.Text); // input credit hours from text box

            //Junior and Senior decision body

            //P-S
            {
                if (Hrs >= JUNIOR)
                {
                    if (Name >= 'p' && Name <= 's')
                    {
                        if (Hrs >= SENIOR)
                            MessageBox.Show($"The earliest you can register is {Date1} at {Time1}.");
                        else if (Hrs >= JUNIOR && Hrs < SENIOR)
                            MessageBox.Show($"The earliest you can register is {Date2} at {Time1}.");
                    }
                    //T-Z
                    else if (Name >= 't' && Name <= 'z')
                    {
                        if (Hrs >= SENIOR)
                            MessageBox.Show($"The earliest you can register is {Date1} at {Time2}.");
                        else if (Hrs >= JUNIOR && Hrs < SENIOR)
                            MessageBox.Show($"The earliest you can register is {Date2} at {Time2}.");
                    }
                    //A-D
                    else if (Name >= 'a' && Name <= 'd')
                    {
                        if (Hrs >= SENIOR)
                            MessageBox.Show($"The earliest you can register is {Date1} at {Time3}.");
                        else if (Hrs >= JUNIOR && Hrs < SENIOR)
                            MessageBox.Show($"The earliest you can register is {Date2} at {Time3}.");
                    }
                    //E-I
                    else if (Name >= 'e' && Name <= 'i')
                    {
                        if (Hrs >= SENIOR)
                            MessageBox.Show($"The earliest you can register is {Date1} at {Time4}.");
                        else if (Hrs >= JUNIOR && Hrs < SENIOR)
                            MessageBox.Show($"The earliest you can register is {Date2} at {Time4}.");
                    }
                    //J-O
                    else if (Name >= 'j' && Name <= 'o')
                    {
                        if (Hrs >= SENIOR)
                            MessageBox.Show($"The earliest you can register is {Date1} at {Time5}.");
                        else if (Hrs >= JUNIOR && Hrs < SENIOR)
                            MessageBox.Show($"The earliest you can register is {Date2} at {Time5}.");
                    }
                }

                // Freshman and Sophomore decision body
                else
                {

                    {//Sophomores 30+ not including Fall 2019 and Freshman first group

                        //P-Q
                        if (Name >= 'p' && Name <= 'q')
                        {
                            if (Hrs >= SOPH)
                                MessageBox.Show($"The earliest you can register is {Date3} at {Time1}.");
                            else if (Hrs >= FRESH)
                                MessageBox.Show($"The earliest you can register is {Date5} at {Time1}.");
                        }
                        //R-S
                        else if (Name >= 'r' && Name <= 's')
                        {
                            if (Hrs >= SOPH)
                                MessageBox.Show($"The earliest you can register is {Date3} at {Time2}.");
                            else if (Hrs >= FRESH)
                                MessageBox.Show($"The earliest you can register is {Date5} at {Time2}.");
                        }
                        //T-V
                        else if (Name >= 't' && Name <= 'v')
                        {
                            if (Hrs >= SOPH)
                                MessageBox.Show($"The earliest you can register is {Date3} at {Time3}.");
                            else if (Hrs >= FRESH)
                                MessageBox.Show($"The earliest you can register is {Date5} at {Time3}.");
                        }
                        //W-Z
                        else if (Name >= 'w' && Name <= 'z')
                        {
                            if (Hrs >= SOPH)
                                MessageBox.Show($"The earliest you can register is {Date3} at {Time4}.");
                            else if (Hrs >= FRESH)
                                MessageBox.Show($"The earliest you can register is {Date5} at {Time4}.");
                        }
                        //A-B
                        else if (Name >= 'a' && Name <= 'b')
                        {
                            if (Hrs >= SOPH)
                                MessageBox.Show($"The earliest you can register is {Date3} at {Time5}.");
                            else if (Hrs >= FRESH)
                                MessageBox.Show($"The earliest you can register is {Date5} at {Time5}.");
                        }

                        //Sophomores 30+ prior to Fall 2019 and Freshman second group
                        //C-D
                        if (Name >= 'c' && Name <= 'd')
                        {
                            if (Hrs >= SOPH)
                                MessageBox.Show($"The earliest you can register is {Date4} at {Time1}.");
                            else if (Hrs >= FRESH)
                                MessageBox.Show($"The earliest you can register is {Date6} at {Time1}.");
                        }
                        //E-F
                        if (Name >= 'e' && Name <= 'f')
                        {
                            if (Hrs >= SOPH)
                                MessageBox.Show($"The earliest you can register is {Date4} at {Time2}.");
                            else if (Hrs >= FRESH)
                                MessageBox.Show($"The earliest you can register is {Date6} at {Time2}.");
                        }
                        //G-I 
                        if (Name >= 'g' && Name <= 'i')
                        {
                            if (Hrs >= SOPH)
                                MessageBox.Show($"The earliest you can register is {Date4} at {Time3}.");
                            else if (Hrs >= FRESH)
                                MessageBox.Show($"The earliest you can register is {Date6} at {Time3}.");
                        }
                        //J-L
                        if (Name >= 'j' && Name <= 'l')
                        {
                            if (Hrs >= SOPH)
                                MessageBox.Show($"The earliest you can register is {Date4} at {Time4}.");
                            else if (Hrs >= FRESH)
                                MessageBox.Show($"The earliest you can register is {Date6} at {Time4}.");
                        }
                        //M-O
                        if (Name >= 'm' && Name <= 'o')
                        {
                            if (Hrs >= SOPH)
                                MessageBox.Show($"The earliest you can register is {Date4} at {Time5}.");
                            else if (Hrs >= FRESH)
                                MessageBox.Show($"The earliest you can register is {Date6} at {Time5}.");
                        }
                    }
                }

            }
        }
    }
}
