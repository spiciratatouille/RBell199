﻿namespace Program2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LastInLbl = new System.Windows.Forms.Label();
            this.CreditHrsLbl = new System.Windows.Forms.Label();
            this.LastInInput = new System.Windows.Forms.TextBox();
            this.CreditHrsInput = new System.Windows.Forms.TextBox();
            this.CompBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LastInLbl
            // 
            this.LastInLbl.AutoSize = true;
            this.LastInLbl.Location = new System.Drawing.Point(12, 9);
            this.LastInLbl.Name = "LastInLbl";
            this.LastInLbl.Size = new System.Drawing.Size(120, 20);
            this.LastInLbl.TabIndex = 0;
            this.LastInLbl.Text = "Enter last initial:";
            // 
            // CreditHrsLbl
            // 
            this.CreditHrsLbl.AutoSize = true;
            this.CreditHrsLbl.Location = new System.Drawing.Point(12, 53);
            this.CreditHrsLbl.Name = "CreditHrsLbl";
            this.CreditHrsLbl.Size = new System.Drawing.Size(139, 20);
            this.CreditHrsLbl.TabIndex = 1;
            this.CreditHrsLbl.Text = "Enter credit hours:";
            // 
            // LastInInput
            // 
            this.LastInInput.Location = new System.Drawing.Point(183, 6);
            this.LastInInput.Name = "LastInInput";
            this.LastInInput.Size = new System.Drawing.Size(100, 26);
            this.LastInInput.TabIndex = 2;
            // 
            // CreditHrsInput
            // 
            this.CreditHrsInput.Location = new System.Drawing.Point(183, 50);
            this.CreditHrsInput.Name = "CreditHrsInput";
            this.CreditHrsInput.Size = new System.Drawing.Size(100, 26);
            this.CreditHrsInput.TabIndex = 3;
            // 
            // CompBtn
            // 
            this.CompBtn.Location = new System.Drawing.Point(183, 116);
            this.CompBtn.Name = "CompBtn";
            this.CompBtn.Size = new System.Drawing.Size(100, 53);
            this.CompBtn.TabIndex = 4;
            this.CompBtn.Text = "When Can I Register?";
            this.CompBtn.UseVisualStyleBackColor = true;
            this.CompBtn.Click += new System.EventHandler(this.CompBtn_Click);
            // 
            // Program2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 247);
            this.Controls.Add(this.CompBtn);
            this.Controls.Add(this.CreditHrsInput);
            this.Controls.Add(this.LastInInput);
            this.Controls.Add(this.CreditHrsLbl);
            this.Controls.Add(this.LastInLbl);
            this.Name = "Program2";
            this.Text = "When Can I Register?";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LastInLbl;
        private System.Windows.Forms.Label CreditHrsLbl;
        private System.Windows.Forms.TextBox LastInInput;
        private System.Windows.Forms.TextBox CreditHrsInput;
        private System.Windows.Forms.Button CompBtn;
    }
}

