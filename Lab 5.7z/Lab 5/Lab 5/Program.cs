﻿// Grading ID: J1559
// Lab 5
// CIS199-01
// Due: 10/27/2019
// This program displays 4 different star patterns
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Lab_5
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MAX_ROWS = 10; // defines maximum amount of rows
            int row; // integer for row number

            WriteLine("Pattern A \n"); // first pattern
            for (row = 1; row <= MAX_ROWS; row++)
            {
                for (int star = 1; star <= row; star++)
                    Write("*");
                WriteLine();
            }

            WriteLine("Pattern B \n"); // second pattern
            for (row = 1; row <= MAX_ROWS; row++)
            {
                for (int star = 10; star >= row; star--)
                    Write("*");
                WriteLine();
            }

            WriteLine("Pattern C \n"); // third pattern
            for (row = 1; row <= MAX_ROWS; row++)
            {
                for (int spaces = 8; spaces >= MAX_ROWS-row; spaces--)
                {
                    Write(" ");
                }
                for (int star = 10; star >= row; star--)
                {
                    Write("*");
                }
                WriteLine();

            }
            WriteLine("Pattern D\n"); // fourth pattern
            for (row = 1; row <= MAX_ROWS; row++)
            {
                for (int spaces = 1; spaces <= MAX_ROWS - row; spaces++)
                {
                    Write(" ");
                }
                for (int star = 1; star <= row; star++)
                {
                    Write("*");
                }
                WriteLine();
            }
            
        }
    }
}
