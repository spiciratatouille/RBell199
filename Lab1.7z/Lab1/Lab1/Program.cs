﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Grading ID:     J1559");
            WriteLine("Hobbies:        Cooking and reading");
            WriteLine("Favorite Book:  Blink");
            WriteLine("Favorite Movie: Return of the Jedi");
        }

        
        
            
        
    }
}
