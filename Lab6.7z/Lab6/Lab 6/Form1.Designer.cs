﻿namespace Lab_6
{
    partial class Lab6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordsLbl = new System.Windows.Forms.Label();
            this.gradeLbl = new System.Windows.Forms.Label();
            this.ScoreInputTxt = new System.Windows.Forms.TextBox();
            this.GradeOut = new System.Windows.Forms.Label();
            this.CalcBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wordsLbl
            // 
            this.wordsLbl.AutoSize = true;
            this.wordsLbl.Location = new System.Drawing.Point(29, 32);
            this.wordsLbl.Name = "wordsLbl";
            this.wordsLbl.Size = new System.Drawing.Size(138, 20);
            this.wordsLbl.TabIndex = 0;
            this.wordsLbl.Text = "Words per minute:";
            // 
            // gradeLbl
            // 
            this.gradeLbl.AutoSize = true;
            this.gradeLbl.Location = new System.Drawing.Point(29, 93);
            this.gradeLbl.Name = "gradeLbl";
            this.gradeLbl.Size = new System.Drawing.Size(58, 20);
            this.gradeLbl.TabIndex = 1;
            this.gradeLbl.Text = "Grade:";
            // 
            // ScoreInputTxt
            // 
            this.ScoreInputTxt.Location = new System.Drawing.Point(206, 29);
            this.ScoreInputTxt.Name = "ScoreInputTxt";
            this.ScoreInputTxt.Size = new System.Drawing.Size(100, 26);
            this.ScoreInputTxt.TabIndex = 2;
            // 
            // GradeOut
            // 
            this.GradeOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.GradeOut.Location = new System.Drawing.Point(206, 93);
            this.GradeOut.Name = "GradeOut";
            this.GradeOut.Size = new System.Drawing.Size(100, 20);
            this.GradeOut.TabIndex = 3;
            // 
            // CalcBtn
            // 
            this.CalcBtn.Location = new System.Drawing.Point(206, 169);
            this.CalcBtn.Name = "CalcBtn";
            this.CalcBtn.Size = new System.Drawing.Size(100, 30);
            this.CalcBtn.TabIndex = 4;
            this.CalcBtn.Text = "Calculate";
            this.CalcBtn.UseVisualStyleBackColor = true;
            this.CalcBtn.Click += new System.EventHandler(this.CalcBtn_Click);
            // 
            // Lab6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 234);
            this.Controls.Add(this.CalcBtn);
            this.Controls.Add(this.GradeOut);
            this.Controls.Add(this.ScoreInputTxt);
            this.Controls.Add(this.gradeLbl);
            this.Controls.Add(this.wordsLbl);
            this.Name = "Lab6";
            this.Text = "Lab 6";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wordsLbl;
        private System.Windows.Forms.Label gradeLbl;
        private System.Windows.Forms.TextBox ScoreInputTxt;
        private System.Windows.Forms.Label GradeOut;
        private System.Windows.Forms.Button CalcBtn;
    }
}

