﻿//Lab 6
//ID: J1559
//CIS199-01
//Due: 10/27/2019
//when user inputs the words per minute, a grade is outputted

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace Lab_6
{
    public partial class Lab6 : Form
    {
        public Lab6()
        {
            InitializeComponent();
        }
        // activates once user clicks button
        private void CalcBtn_Click(object sender, EventArgs e)
        {
            int[] words = { 0, 16, 31, 51, 76 }; //array for minimum words typed
            string[] grades = { "F", "D", "C", "B", "A" }; //array for correlating letter grades

            int wordsLbl; //number of words typed
            int x = words.Length - 1; //maximum amount of times loop will execute
            bool found = false; //states whether or not value was found

            // parse user input
            if (int.TryParse(ScoreInputTxt.Text, out wordsLbl) && wordsLbl >= 0);
            {
                while (x >= 0 && !found) //executes until value is true
                { if (wordsLbl >= words[x]) //determines position in array and stops when true
                        found = true;
                    else //restarts loop
                        --x;
                }
            }
            if (found) //outputs letter grade
                GradeOut.Text = grades[x];
            else
                MessageBox.Show("Please enter a valid number"); //outputs if number isn't valid

        }
        
    }
}
