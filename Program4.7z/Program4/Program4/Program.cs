﻿// ID: J1559
// Program 4
// Due: 12/3/2019
// CIS 199-01
// This program lists book information, checks them out, then returns them, listing the information again after these changes
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Program4
{
    class LibraryBook
    {
        private string title; //book title
        private string publisher; //book publisher
        private int copyrightYear; //copyright year
        private string callNum; //book call number
        public bool checkedOut; //checkout status of book
        int DEFAULT_YEAR = 2019; //default copyright year

        public LibraryBook (string title, string author, string publisher, int copyrightYear, string callNum)
        {
            Title = title;
            Author = author;
            Publisher = publisher;
            CopyrightYear = copyrightYear;
            CallNum = callNum;
        }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }

        public int CopyrightYear
        {
            get
            {
                return copyrightYear;
            }
            set //ensures a valid copyright year and if not, sets it to a default year of 2019
            {
                if (value > 0)
                    copyrightYear = value;
                else
                    copyrightYear = DEFAULT_YEAR;
            }
        }
        public string CallNum { get; set; }

        public void CheckOut()
        //precondition: none
        //postcondition: changes book checkout status to true
        {
            checkedOut = true;
        }
        public void ReturnToShelf()
        //precondition: none
        //postcondition: changes book checkout status to false
        {
            checkedOut = false;
        }
        public bool IsCheckedOut()
        //precondition: none
        //postcondition: checks whether book is checked out or not
        {
            if (checkedOut)
                return true;
            else
                return false;
        }
        public override string ToString() //gathers all the book info into a string
        {
            return $"Title: {Title}" + Environment.NewLine +
                $"Author: {Author}" + Environment.NewLine +
                $"Publisher: {Publisher}" + Environment.NewLine +
                $"Copyright Year: {CopyrightYear}" + Environment.NewLine +
                $"Call Number: {CallNum}" + Environment.NewLine +
                $"Checked out: {checkedOut}";
        }
    }
    class Test
    {
        static void Main(string[] args)
        {
            LibraryBook book1 = new LibraryBook("It", "Stephen King", "Viking", 1986, "11111"); //book 1 info
            LibraryBook book2 = new LibraryBook("Blink", "Malcolm Gladwell", "Bay Back Books", 2006, "22222"); //book 2 info
            LibraryBook book3 = new LibraryBook("Speed", "William Boroughs", "Olympia Press", 1970, "33333"); //book 3 info
            LibraryBook book4 = new LibraryBook("Freedom", "Jonathan Franzen", "Farrar", 2010, "44444"); //book 4 info
            LibraryBook book5 = new LibraryBook("1984", "George Orwell", "Secker & Warburg", 1949, "55555"); //book 5 info

            LibraryBook[] books = { book1, book2, book3, book4, book5 }; //sets books into an array

            DisplayBooks(books); //display book info
            //checkout books
            book1.CheckOut();
            book2.CheckOut();

            DisplayBooks(books); //display book info
            //return books
            book1.ReturnToShelf();
            book2.ReturnToShelf();

            DisplayBooks(books); //display book info
        }
        static void DisplayBooks(LibraryBook[] books) //loop through array of books and display their info
        {
            for (int i = 0; i < books.Length; i++)
            {
                WriteLine($"{books[i].ToString()}");
                WriteLine();
            }
        }
    }

    
}
    

