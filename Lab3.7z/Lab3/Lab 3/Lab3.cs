﻿// User ID: J1559
// Lab 3
// Due: 09/22/2019
// CIS 199-01
// This program calculates diameter, surface area, and volume with the radius that is entered by user

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_3
{
    public partial class Lab3 : Form
    {
        public Lab3()
        {
            InitializeComponent();
        }
        //Activates program once Calculate button is clicked
        private void CalcBtn_Click(object sender, EventArgs e)
        {
            double radius; //radius value
            double Diameter; //diameter value
            double SurfaceArea; //surface area value
            double Volume; //volume value

            radius = double.Parse(RadiusIn.Text); //assigns input to radius value

            Diameter = radius * 2; //calculates diameter with entered radius
            SurfaceArea = 4 * Math.PI * Math.Pow(radius, 2); //calculates surface area with entered radius 
            Volume = (4 * Math.PI * Math.Pow(radius, 3) / 3); //calculates volume with entered radius

            DiameterOut.Text = $"{Diameter:F2}"; //places diameter in the DiameterOut label
            SurfaceAreaOut.Text = $"{SurfaceArea:F2}"; //places surface area in SurfaceAreaOut label
            VolumeOut.Text = $"{Volume:F2}"; //places volume in VolumeOut label

            

        }
    }
}
