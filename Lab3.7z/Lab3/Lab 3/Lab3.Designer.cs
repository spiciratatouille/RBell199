﻿namespace Lab_3
{
    partial class Lab3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Lab3));
            this.RadiusLabel = new System.Windows.Forms.Label();
            this.RadiusIn = new System.Windows.Forms.TextBox();
            this.Diameter = new System.Windows.Forms.Label();
            this.SurfaceArea = new System.Windows.Forms.Label();
            this.Volume = new System.Windows.Forms.Label();
            this.DiameterOut = new System.Windows.Forms.Label();
            this.SurfaceAreaOut = new System.Windows.Forms.Label();
            this.VolumeOut = new System.Windows.Forms.Label();
            this.CalcBtn = new System.Windows.Forms.Button();
            this.SphereTop = new System.Windows.Forms.PictureBox();
            this.SphereBottom = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.SphereTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SphereBottom)).BeginInit();
            this.SuspendLayout();
            // 
            // RadiusLabel
            // 
            this.RadiusLabel.AutoSize = true;
            this.RadiusLabel.Location = new System.Drawing.Point(163, 26);
            this.RadiusLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.RadiusLabel.Name = "RadiusLabel";
            this.RadiusLabel.Size = new System.Drawing.Size(90, 13);
            this.RadiusLabel.TabIndex = 0;
            this.RadiusLabel.Text = "Radius of sphere:";
            // 
            // RadiusIn
            // 
            this.RadiusIn.Location = new System.Drawing.Point(269, 23);
            this.RadiusIn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RadiusIn.Name = "RadiusIn";
            this.RadiusIn.Size = new System.Drawing.Size(68, 20);
            this.RadiusIn.TabIndex = 1;
            // 
            // Diameter
            // 
            this.Diameter.AutoSize = true;
            this.Diameter.Location = new System.Drawing.Point(15, 200);
            this.Diameter.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Diameter.Name = "Diameter";
            this.Diameter.Size = new System.Drawing.Size(52, 13);
            this.Diameter.TabIndex = 2;
            this.Diameter.Text = "Diameter:";
            // 
            // SurfaceArea
            // 
            this.SurfaceArea.AutoSize = true;
            this.SurfaceArea.Location = new System.Drawing.Point(15, 248);
            this.SurfaceArea.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.SurfaceArea.Name = "SurfaceArea";
            this.SurfaceArea.Size = new System.Drawing.Size(72, 13);
            this.SurfaceArea.TabIndex = 3;
            this.SurfaceArea.Text = "Surface Area:";
            // 
            // Volume
            // 
            this.Volume.AutoSize = true;
            this.Volume.Location = new System.Drawing.Point(15, 292);
            this.Volume.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Volume.Name = "Volume";
            this.Volume.Size = new System.Drawing.Size(45, 13);
            this.Volume.TabIndex = 4;
            this.Volume.Text = "Volume:";
            // 
            // DiameterOut
            // 
            this.DiameterOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DiameterOut.Location = new System.Drawing.Point(97, 200);
            this.DiameterOut.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DiameterOut.Name = "DiameterOut";
            this.DiameterOut.Size = new System.Drawing.Size(64, 13);
            this.DiameterOut.TabIndex = 5;
            // 
            // SurfaceAreaOut
            // 
            this.SurfaceAreaOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SurfaceAreaOut.Location = new System.Drawing.Point(97, 247);
            this.SurfaceAreaOut.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.SurfaceAreaOut.Name = "SurfaceAreaOut";
            this.SurfaceAreaOut.Size = new System.Drawing.Size(64, 14);
            this.SurfaceAreaOut.TabIndex = 6;
            // 
            // VolumeOut
            // 
            this.VolumeOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.VolumeOut.Location = new System.Drawing.Point(97, 290);
            this.VolumeOut.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.VolumeOut.Name = "VolumeOut";
            this.VolumeOut.Size = new System.Drawing.Size(64, 15);
            this.VolumeOut.TabIndex = 7;
            // 
            // CalcBtn
            // 
            this.CalcBtn.Location = new System.Drawing.Point(269, 68);
            this.CalcBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.CalcBtn.Name = "CalcBtn";
            this.CalcBtn.Size = new System.Drawing.Size(67, 21);
            this.CalcBtn.TabIndex = 8;
            this.CalcBtn.Text = "Calculate";
            this.CalcBtn.UseVisualStyleBackColor = true;
            this.CalcBtn.Click += new System.EventHandler(this.CalcBtn_Click);
            // 
            // SphereTop
            // 
            this.SphereTop.Image = ((System.Drawing.Image)(resources.GetObject("SphereTop.Image")));
            this.SphereTop.Location = new System.Drawing.Point(8, 8);
            this.SphereTop.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SphereTop.Name = "SphereTop";
            this.SphereTop.Size = new System.Drawing.Size(150, 150);
            this.SphereTop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SphereTop.TabIndex = 9;
            this.SphereTop.TabStop = false;
            // 
            // SphereBottom
            // 
            this.SphereBottom.Image = ((System.Drawing.Image)(resources.GetObject("SphereBottom.Image")));
            this.SphereBottom.Location = new System.Drawing.Point(223, 200);
            this.SphereBottom.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SphereBottom.Name = "SphereBottom";
            this.SphereBottom.Size = new System.Drawing.Size(150, 150);
            this.SphereBottom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SphereBottom.TabIndex = 10;
            this.SphereBottom.TabStop = false;
            // 
            // Lab3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 361);
            this.Controls.Add(this.SphereBottom);
            this.Controls.Add(this.SphereTop);
            this.Controls.Add(this.CalcBtn);
            this.Controls.Add(this.VolumeOut);
            this.Controls.Add(this.SurfaceAreaOut);
            this.Controls.Add(this.DiameterOut);
            this.Controls.Add(this.Volume);
            this.Controls.Add(this.SurfaceArea);
            this.Controls.Add(this.Diameter);
            this.Controls.Add(this.RadiusIn);
            this.Controls.Add(this.RadiusLabel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Lab3";
            this.Text = "Lab 3";
            ((System.ComponentModel.ISupportInitialize)(this.SphereTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SphereBottom)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label RadiusLabel;
        private System.Windows.Forms.TextBox RadiusIn;
        private System.Windows.Forms.Label Diameter;
        private System.Windows.Forms.Label SurfaceArea;
        private System.Windows.Forms.Label Volume;
        private System.Windows.Forms.Label DiameterOut;
        private System.Windows.Forms.Label SurfaceAreaOut;
        private System.Windows.Forms.Label VolumeOut;
        private System.Windows.Forms.Button CalcBtn;
        private System.Windows.Forms.PictureBox SphereTop;
        private System.Windows.Forms.PictureBox SphereBottom;
    }
}

