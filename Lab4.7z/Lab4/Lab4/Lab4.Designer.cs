﻿namespace Lab4
{
    partial class Lab4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpaLbl = new System.Windows.Forms.Label();
            this.scoreLbl = new System.Windows.Forms.Label();
            this.gpaBox = new System.Windows.Forms.TextBox();
            this.scoreBox = new System.Windows.Forms.TextBox();
            this.decisionLbl = new System.Windows.Forms.Label();
            this.calcBtn = new System.Windows.Forms.Button();
            this.yesLbl = new System.Windows.Forms.Label();
            this.noLbl = new System.Windows.Forms.Label();
            this.admissionsLbl = new System.Windows.Forms.Label();
            this.acceptOutputLbl = new System.Windows.Forms.Label();
            this.rejectOutputLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gpaLbl
            // 
            this.gpaLbl.AutoSize = true;
            this.gpaLbl.Location = new System.Drawing.Point(31, 31);
            this.gpaLbl.Name = "gpaLbl";
            this.gpaLbl.Size = new System.Drawing.Size(139, 13);
            this.gpaLbl.TabIndex = 0;
            this.gpaLbl.Text = "Enter grade point average : ";
            // 
            // scoreLbl
            // 
            this.scoreLbl.AutoSize = true;
            this.scoreLbl.Location = new System.Drawing.Point(29, 72);
            this.scoreLbl.Name = "scoreLbl";
            this.scoreLbl.Size = new System.Drawing.Size(141, 13);
            this.scoreLbl.TabIndex = 1;
            this.scoreLbl.Text = "Enter admissions test score: ";
            // 
            // gpaBox
            // 
            this.gpaBox.Location = new System.Drawing.Point(199, 31);
            this.gpaBox.Name = "gpaBox";
            this.gpaBox.Size = new System.Drawing.Size(100, 20);
            this.gpaBox.TabIndex = 2;
            // 
            // scoreBox
            // 
            this.scoreBox.Location = new System.Drawing.Point(199, 72);
            this.scoreBox.Name = "scoreBox";
            this.scoreBox.Size = new System.Drawing.Size(100, 20);
            this.scoreBox.TabIndex = 3;
            // 
            // decisionLbl
            // 
            this.decisionLbl.AutoSize = true;
            this.decisionLbl.Location = new System.Drawing.Point(61, 111);
            this.decisionLbl.Name = "decisionLbl";
            this.decisionLbl.Size = new System.Drawing.Size(109, 13);
            this.decisionLbl.TabIndex = 4;
            this.decisionLbl.Text = "Admissions Decision: ";
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(117, 164);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(95, 23);
            this.calcBtn.TabIndex = 5;
            this.calcBtn.Text = "See decision";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // yesLbl
            // 
            this.yesLbl.AutoSize = true;
            this.yesLbl.Location = new System.Drawing.Point(31, 223);
            this.yesLbl.Name = "yesLbl";
            this.yesLbl.Size = new System.Drawing.Size(59, 13);
            this.yesLbl.TabIndex = 6;
            this.yesLbl.Text = "Accepted: ";
            // 
            // noLbl
            // 
            this.noLbl.AutoSize = true;
            this.noLbl.Location = new System.Drawing.Point(34, 255);
            this.noLbl.Name = "noLbl";
            this.noLbl.Size = new System.Drawing.Size(56, 13);
            this.noLbl.TabIndex = 7;
            this.noLbl.Text = "Rejected: ";
            // 
            // admissionsLbl
            // 
            this.admissionsLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.admissionsLbl.Location = new System.Drawing.Point(199, 110);
            this.admissionsLbl.Name = "admissionsLbl";
            this.admissionsLbl.Size = new System.Drawing.Size(100, 22);
            this.admissionsLbl.TabIndex = 8;
            // 
            // acceptOutputLbl
            // 
            this.acceptOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.acceptOutputLbl.Location = new System.Drawing.Point(96, 213);
            this.acceptOutputLbl.Name = "acceptOutputLbl";
            this.acceptOutputLbl.Size = new System.Drawing.Size(50, 23);
            this.acceptOutputLbl.TabIndex = 9;
            // 
            // rejectOutputLbl
            // 
            this.rejectOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rejectOutputLbl.Location = new System.Drawing.Point(96, 255);
            this.rejectOutputLbl.Name = "rejectOutputLbl";
            this.rejectOutputLbl.Size = new System.Drawing.Size(50, 23);
            this.rejectOutputLbl.TabIndex = 10;
            // 
            // Lab4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 301);
            this.Controls.Add(this.rejectOutputLbl);
            this.Controls.Add(this.acceptOutputLbl);
            this.Controls.Add(this.admissionsLbl);
            this.Controls.Add(this.noLbl);
            this.Controls.Add(this.yesLbl);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.decisionLbl);
            this.Controls.Add(this.scoreBox);
            this.Controls.Add(this.gpaBox);
            this.Controls.Add(this.scoreLbl);
            this.Controls.Add(this.gpaLbl);
            this.Name = "Lab4";
            this.Text = "Lab 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gpaLbl;
        private System.Windows.Forms.Label scoreLbl;
        private System.Windows.Forms.TextBox gpaBox;
        private System.Windows.Forms.TextBox scoreBox;
        private System.Windows.Forms.Label decisionLbl;
        private System.Windows.Forms.Button calcBtn;
        private System.Windows.Forms.Label yesLbl;
        private System.Windows.Forms.Label noLbl;
        private System.Windows.Forms.Label admissionsLbl;
        private System.Windows.Forms.Label acceptOutputLbl;
        private System.Windows.Forms.Label rejectOutputLbl;
    }
}

