﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Lab4 : Form
    {
        int acceptCount;
        int rejectCount;

        public Lab4()
        {
            InitializeComponent();
        }

        private void calcBtn_Click(object sender, EventArgs e)
        {
            double gpa;
            double test;
            const double POINT_AVG = 3.0;
            const int TEST_LOW = 60;
            const int TEST_HIGH = 80;
            const double GPA_MIN = 0.0;
            const double GPA_HIGH = 4.0;
           


            if(double.TryParse(gpaBox.Text, out gpa) && gpa >= GPA_MIN && gpa <= GPA_HIGH)
            {
                if (double.TryParse(scoreBox.Text, out test) && test >= TEST_LOW && test <= TEST_HIGH)
                {
                    if (gpa >= POINT_AVG && test >= TEST_LOW)
                    {
                        admissionsLbl.Text = "Accept";
                        ++acceptCount;
                        acceptOutputLbl.Text = $"{acceptCount}";
                    }
                    else if (test >= TEST_HIGH)
                    {
                        admissionsLbl.Text = "Accept";
                        ++acceptCount;
                        acceptOutputLbl.Text = $"{acceptCount}";
                    }
                    else
                    {
                        admissionsLbl.Text = "Reject";
                        ++rejectCount;
                        rejectOutputLbl.Text = $"{rejectCount}";
                    }

                }
                else MessageBox.Show("Enter a valid test score!");
            }
            else MessageBox.Show("Enter a valid gpa!");






        }
    }
}
