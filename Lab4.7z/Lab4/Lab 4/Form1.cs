﻿// Grading ID: J1559
// Lab 4
// 09/29/2019
//CIS199-01
//Determines whether or not user is accepted or rejected based on GPA and test score
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace Lab_4
{
    public partial class AdmissionChecker : Form
    {
        private int CounterAccept = 0; //accept variable for counter
        private int CounterReject = 0; //reject variable for counter
        public AdmissionChecker()
        {
            InitializeComponent();
        }
        // activates once button is clicked
        private void CheckBtn_Click(object sender, EventArgs e)
        {
            float GPA; //variable for gpa
            int Score; //variable for score

            if (float.TryParse(GPAInput.Text, out GPA))
            {
                {
                    if (GPA >= 0 && GPA <= 4)
                    {
                        GPA = float.Parse(GPAInput.Text);
                    }
                    else
                    {
                        MessageBox.Show("GPA not valid!");
                    }

                }
                //determine if score is valid
                if (int.TryParse(ScoreInput.Text, out Score))
                    if (Score >= 0 && Score <= 100)
                    {
                        Score = int.Parse(ScoreInput.Text);
                    }
                    else MessageBox.Show("Test score not valid!");
                //accept/reject counts
                CounterAccept = ++CounterAccept;
                CounterReject = ++CounterReject;

                //accept or reject based on inputs
                if ((GPA >= 3.0 && Score >= 60) || (GPA < 3.0 && Score >= 80))
                    AnswerLabel.Text = "Accept";
                else
                {
                    AnswerLabel.Text = "Reject";
                }
                //output to accept/reject counters
                if (AnswerLabel.Text == "Accept")
                    AcceptTotalLabel.Text = $"{CounterAccept}";
                if (AnswerLabel.Text == "Reject")
                    RejectTotalLabel.Text = $"{CounterReject}";
            }

           
        }
    }
}
