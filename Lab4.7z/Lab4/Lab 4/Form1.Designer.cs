﻿namespace Lab_4
{
    partial class AdmissionChecker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GPALabel = new System.Windows.Forms.Label();
            this.ScoreLabel = new System.Windows.Forms.Label();
            this.GPAInput = new System.Windows.Forms.TextBox();
            this.ScoreInput = new System.Windows.Forms.TextBox();
            this.CheckBtn = new System.Windows.Forms.Button();
            this.AccRejLabel = new System.Windows.Forms.Label();
            this.AcceptCounterLabel = new System.Windows.Forms.Label();
            this.RejectCounterLabel = new System.Windows.Forms.Label();
            this.AnswerLabel = new System.Windows.Forms.Label();
            this.AcceptTotalLabel = new System.Windows.Forms.Label();
            this.RejectTotalLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // GPALabel
            // 
            this.GPALabel.AutoSize = true;
            this.GPALabel.Location = new System.Drawing.Point(12, 9);
            this.GPALabel.Name = "GPALabel";
            this.GPALabel.Size = new System.Drawing.Size(90, 20);
            this.GPALabel.TabIndex = 0;
            this.GPALabel.Text = "Enter GPA:";
            // 
            // ScoreLabel
            // 
            this.ScoreLabel.AutoSize = true;
            this.ScoreLabel.Location = new System.Drawing.Point(12, 53);
            this.ScoreLabel.Name = "ScoreLabel";
            this.ScoreLabel.Size = new System.Drawing.Size(210, 20);
            this.ScoreLabel.TabIndex = 1;
            this.ScoreLabel.Text = "Enter Admission Test Score:";
            // 
            // GPAInput
            // 
            this.GPAInput.Location = new System.Drawing.Point(286, 6);
            this.GPAInput.Name = "GPAInput";
            this.GPAInput.Size = new System.Drawing.Size(100, 26);
            this.GPAInput.TabIndex = 2;
            // 
            // ScoreInput
            // 
            this.ScoreInput.Location = new System.Drawing.Point(286, 53);
            this.ScoreInput.Name = "ScoreInput";
            this.ScoreInput.Size = new System.Drawing.Size(100, 26);
            this.ScoreInput.TabIndex = 3;
            // 
            // CheckBtn
            // 
            this.CheckBtn.Location = new System.Drawing.Point(286, 248);
            this.CheckBtn.Name = "CheckBtn";
            this.CheckBtn.Size = new System.Drawing.Size(100, 31);
            this.CheckBtn.TabIndex = 4;
            this.CheckBtn.Text = "Check";
            this.CheckBtn.UseVisualStyleBackColor = true;
            this.CheckBtn.Click += new System.EventHandler(this.CheckBtn_Click);
            // 
            // AccRejLabel
            // 
            this.AccRejLabel.AutoSize = true;
            this.AccRejLabel.Location = new System.Drawing.Point(12, 104);
            this.AccRejLabel.Name = "AccRejLabel";
            this.AccRejLabel.Size = new System.Drawing.Size(131, 20);
            this.AccRejLabel.TabIndex = 5;
            this.AccRejLabel.Text = "Accept or Reject:";
            // 
            // AcceptCounterLabel
            // 
            this.AcceptCounterLabel.AutoSize = true;
            this.AcceptCounterLabel.Location = new System.Drawing.Point(12, 153);
            this.AcceptCounterLabel.Name = "AcceptCounterLabel";
            this.AcceptCounterLabel.Size = new System.Drawing.Size(81, 20);
            this.AcceptCounterLabel.TabIndex = 6;
            this.AcceptCounterLabel.Text = "Accepted:";
            // 
            // RejectCounterLabel
            // 
            this.RejectCounterLabel.AutoSize = true;
            this.RejectCounterLabel.Location = new System.Drawing.Point(12, 201);
            this.RejectCounterLabel.Name = "RejectCounterLabel";
            this.RejectCounterLabel.Size = new System.Drawing.Size(77, 20);
            this.RejectCounterLabel.TabIndex = 7;
            this.RejectCounterLabel.Text = "Rejected:";
            // 
            // AnswerLabel
            // 
            this.AnswerLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AnswerLabel.Location = new System.Drawing.Point(286, 104);
            this.AnswerLabel.Name = "AnswerLabel";
            this.AnswerLabel.Size = new System.Drawing.Size(100, 20);
            this.AnswerLabel.TabIndex = 8;
            // 
            // AcceptTotalLabel
            // 
            this.AcceptTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AcceptTotalLabel.Location = new System.Drawing.Point(286, 153);
            this.AcceptTotalLabel.Name = "AcceptTotalLabel";
            this.AcceptTotalLabel.Size = new System.Drawing.Size(100, 20);
            this.AcceptTotalLabel.TabIndex = 9;
            // 
            // RejectTotalLabel
            // 
            this.RejectTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RejectTotalLabel.Location = new System.Drawing.Point(286, 201);
            this.RejectTotalLabel.Name = "RejectTotalLabel";
            this.RejectTotalLabel.Size = new System.Drawing.Size(100, 20);
            this.RejectTotalLabel.TabIndex = 10;
            // 
            // AdmissionChecker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 292);
            this.Controls.Add(this.RejectTotalLabel);
            this.Controls.Add(this.AcceptTotalLabel);
            this.Controls.Add(this.AnswerLabel);
            this.Controls.Add(this.RejectCounterLabel);
            this.Controls.Add(this.AcceptCounterLabel);
            this.Controls.Add(this.AccRejLabel);
            this.Controls.Add(this.CheckBtn);
            this.Controls.Add(this.ScoreInput);
            this.Controls.Add(this.GPAInput);
            this.Controls.Add(this.ScoreLabel);
            this.Controls.Add(this.GPALabel);
            this.Name = "AdmissionChecker";
            this.Text = "Admission Checker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label GPALabel;
        private System.Windows.Forms.Label ScoreLabel;
        private System.Windows.Forms.TextBox GPAInput;
        private System.Windows.Forms.TextBox ScoreInput;
        private System.Windows.Forms.Button CheckBtn;
        private System.Windows.Forms.Label AccRejLabel;
        private System.Windows.Forms.Label AcceptCounterLabel;
        private System.Windows.Forms.Label RejectCounterLabel;
        private System.Windows.Forms.Label AnswerLabel;
        private System.Windows.Forms.Label AcceptTotalLabel;
        private System.Windows.Forms.Label RejectTotalLabel;
    }
}

