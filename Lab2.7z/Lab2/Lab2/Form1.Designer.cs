﻿namespace Lab2
{
    partial class Lab2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BillAmt = new System.Windows.Forms.Label();
            this.Tip1 = new System.Windows.Forms.Label();
            this.Tip2 = new System.Windows.Forms.Label();
            this.Tip3 = new System.Windows.Forms.Label();
            this.Bill = new System.Windows.Forms.TextBox();
            this.Tip1Amt = new System.Windows.Forms.Label();
            this.Tip2Amt = new System.Windows.Forms.Label();
            this.Tip3Amt = new System.Windows.Forms.Label();
            this.CalcBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BillAmt
            // 
            this.BillAmt.AutoSize = true;
            this.BillAmt.Location = new System.Drawing.Point(22, 32);
            this.BillAmt.Name = "BillAmt";
            this.BillAmt.Size = new System.Drawing.Size(146, 20);
            this.BillAmt.TabIndex = 0;
            this.BillAmt.Text = "Enter price of meal:";
            // 
            // Tip1
            // 
            this.Tip1.Location = new System.Drawing.Point(22, 82);
            this.Tip1.Name = "Tip1";
            this.Tip1.Size = new System.Drawing.Size(136, 21);
            this.Tip1.TabIndex = 1;
            this.Tip1.Text = "15%";
            // 
            // Tip2
            // 
            this.Tip2.Location = new System.Drawing.Point(22, 137);
            this.Tip2.Name = "Tip2";
            this.Tip2.Size = new System.Drawing.Size(136, 25);
            this.Tip2.TabIndex = 2;
            this.Tip2.Text = "18%";
            // 
            // Tip3
            // 
            this.Tip3.Location = new System.Drawing.Point(22, 194);
            this.Tip3.Name = "Tip3";
            this.Tip3.Size = new System.Drawing.Size(136, 23);
            this.Tip3.TabIndex = 3;
            this.Tip3.Text = "20%";
            // 
            // Bill
            // 
            this.Bill.Location = new System.Drawing.Point(225, 26);
            this.Bill.Name = "Bill";
            this.Bill.Size = new System.Drawing.Size(100, 26);
            this.Bill.TabIndex = 4;
            // 
            // Tip1Amt
            // 
            this.Tip1Amt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Tip1Amt.Location = new System.Drawing.Point(225, 81);
            this.Tip1Amt.Name = "Tip1Amt";
            this.Tip1Amt.Size = new System.Drawing.Size(100, 22);
            this.Tip1Amt.TabIndex = 5;
            // 
            // Tip2Amt
            // 
            this.Tip2Amt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Tip2Amt.Location = new System.Drawing.Point(225, 137);
            this.Tip2Amt.Name = "Tip2Amt";
            this.Tip2Amt.Size = new System.Drawing.Size(100, 25);
            this.Tip2Amt.TabIndex = 6;
            // 
            // Tip3Amt
            // 
            this.Tip3Amt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Tip3Amt.Location = new System.Drawing.Point(225, 197);
            this.Tip3Amt.Name = "Tip3Amt";
            this.Tip3Amt.Size = new System.Drawing.Size(100, 20);
            this.Tip3Amt.TabIndex = 7;
            // 
            // CalcBtn
            // 
            this.CalcBtn.Location = new System.Drawing.Point(225, 274);
            this.CalcBtn.Name = "CalcBtn";
            this.CalcBtn.Size = new System.Drawing.Size(100, 65);
            this.CalcBtn.TabIndex = 8;
            this.CalcBtn.Text = "Calculate Tip";
            this.CalcBtn.UseVisualStyleBackColor = true;
            this.CalcBtn.Click += new System.EventHandler(this.CalcBtn_Click);
            // 
            // Lab2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 401);
            this.Controls.Add(this.CalcBtn);
            this.Controls.Add(this.Tip3Amt);
            this.Controls.Add(this.Tip2Amt);
            this.Controls.Add(this.Tip1Amt);
            this.Controls.Add(this.Bill);
            this.Controls.Add(this.Tip3);
            this.Controls.Add(this.Tip2);
            this.Controls.Add(this.Tip1);
            this.Controls.Add(this.BillAmt);
            this.Name = "Lab2";
            this.Text = "Lab 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label BillAmt;
        private System.Windows.Forms.Label Tip1;
        private System.Windows.Forms.Label Tip2;
        private System.Windows.Forms.Label Tip3;
        private System.Windows.Forms.TextBox Bill;
        private System.Windows.Forms.Label Tip1Amt;
        private System.Windows.Forms.Label Tip2Amt;
        private System.Windows.Forms.Label Tip3Amt;
        private System.Windows.Forms.Button CalcBtn;
    }
}

