﻿// Grading ID: J1559
// Lab 2
// Due Sunday 9/15/2019
// Section: 01
// Program calculates 3 levels of tips when user enters bill amount
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Lab2 : Form
    {
        public Lab2()
        {
            InitializeComponent();
        }

        //Activated once Calculate Tip button is clicked
        private void CalcBtn_Click(object sender, EventArgs e)
        {
            const double Tip1 = 0.15;//Tip rate for 15%
            const double Tip2 = 0.18;//Tip rate for 18%
            const double Tip3 = 0.2;//Tip rate for 20%
            double BillAmt;//Bill amount from text box 
            double Tip1Num;//Calculated tip for 15%
            double Tip2Num;//Calculated tip for 18%
            double Tip3Num;//Calculated tip for 20%

            //Convert entered number to variable
            BillAmt = double.Parse(Bill.Text);
            
            
            //Arithmetic
            Tip1Num = BillAmt * Tip1;
            Tip2Num = BillAmt * Tip2;
            Tip3Num = BillAmt * Tip3;
            
            //Output calculated values to their assigned labels
            Tip1Amt.Text = $"{Tip1Num:C}";
            Tip2Amt.Text = $"{Tip2Num:C}";
            Tip3Amt.Text = $"{Tip3Num:C}";
        }
    }
}
