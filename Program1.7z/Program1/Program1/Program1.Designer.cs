﻿namespace Program1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PerimeterLabel = new System.Windows.Forms.Label();
            this.HeightLabel = new System.Windows.Forms.Label();
            this.DoorsLabel = new System.Windows.Forms.Label();
            this.WindowsLabel = new System.Windows.Forms.Label();
            this.CoatsLabel = new System.Windows.Forms.Label();
            this.WindowsNum = new System.Windows.Forms.TextBox();
            this.DoorsNum = new System.Windows.Forms.TextBox();
            this.HeightNum = new System.Windows.Forms.TextBox();
            this.PerimeterNum = new System.Windows.Forms.TextBox();
            this.CoatsNum = new System.Windows.Forms.TextBox();
            this.CalcBtn = new System.Windows.Forms.Button();
            this.MinGal = new System.Windows.Forms.Label();
            this.GalToBuy = new System.Windows.Forms.Label();
            this.MinGalOut = new System.Windows.Forms.Label();
            this.GalToBuyOut = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // PerimeterLabel
            // 
            this.PerimeterLabel.AutoSize = true;
            this.PerimeterLabel.Location = new System.Drawing.Point(8, 6);
            this.PerimeterLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PerimeterLabel.Name = "PerimeterLabel";
            this.PerimeterLabel.Size = new System.Drawing.Size(54, 13);
            this.PerimeterLabel.TabIndex = 0;
            this.PerimeterLabel.Text = "Perimeter:";
            // 
            // HeightLabel
            // 
            this.HeightLabel.AutoSize = true;
            this.HeightLabel.Location = new System.Drawing.Point(8, 30);
            this.HeightLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.HeightLabel.Name = "HeightLabel";
            this.HeightLabel.Size = new System.Drawing.Size(41, 13);
            this.HeightLabel.TabIndex = 1;
            this.HeightLabel.Text = "Height:";
            // 
            // DoorsLabel
            // 
            this.DoorsLabel.AutoSize = true;
            this.DoorsLabel.Location = new System.Drawing.Point(8, 52);
            this.DoorsLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DoorsLabel.Name = "DoorsLabel";
            this.DoorsLabel.Size = new System.Drawing.Size(88, 13);
            this.DoorsLabel.TabIndex = 2;
            this.DoorsLabel.Text = "Number of doors:";
            // 
            // WindowsLabel
            // 
            this.WindowsLabel.AutoSize = true;
            this.WindowsLabel.Location = new System.Drawing.Point(8, 75);
            this.WindowsLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.WindowsLabel.Name = "WindowsLabel";
            this.WindowsLabel.Size = new System.Drawing.Size(103, 13);
            this.WindowsLabel.TabIndex = 3;
            this.WindowsLabel.Text = "Number of windows:";
            // 
            // CoatsLabel
            // 
            this.CoatsLabel.AutoSize = true;
            this.CoatsLabel.Location = new System.Drawing.Point(8, 103);
            this.CoatsLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.CoatsLabel.Name = "CoatsLabel";
            this.CoatsLabel.Size = new System.Drawing.Size(75, 13);
            this.CoatsLabel.TabIndex = 4;
            this.CoatsLabel.Text = "Coats of paint:";
            // 
            // WindowsNum
            // 
            this.WindowsNum.Location = new System.Drawing.Point(113, 75);
            this.WindowsNum.Margin = new System.Windows.Forms.Padding(2);
            this.WindowsNum.Name = "WindowsNum";
            this.WindowsNum.Size = new System.Drawing.Size(68, 20);
            this.WindowsNum.TabIndex = 5;
            // 
            // DoorsNum
            // 
            this.DoorsNum.Location = new System.Drawing.Point(113, 50);
            this.DoorsNum.Margin = new System.Windows.Forms.Padding(2);
            this.DoorsNum.Name = "DoorsNum";
            this.DoorsNum.Size = new System.Drawing.Size(68, 20);
            this.DoorsNum.TabIndex = 6;
            // 
            // HeightNum
            // 
            this.HeightNum.Location = new System.Drawing.Point(113, 28);
            this.HeightNum.Margin = new System.Windows.Forms.Padding(2);
            this.HeightNum.Name = "HeightNum";
            this.HeightNum.Size = new System.Drawing.Size(68, 20);
            this.HeightNum.TabIndex = 7;
            // 
            // PerimeterNum
            // 
            this.PerimeterNum.Location = new System.Drawing.Point(113, 4);
            this.PerimeterNum.Margin = new System.Windows.Forms.Padding(2);
            this.PerimeterNum.Name = "PerimeterNum";
            this.PerimeterNum.Size = new System.Drawing.Size(68, 20);
            this.PerimeterNum.TabIndex = 8;
            // 
            // CoatsNum
            // 
            this.CoatsNum.Location = new System.Drawing.Point(113, 101);
            this.CoatsNum.Margin = new System.Windows.Forms.Padding(2);
            this.CoatsNum.Name = "CoatsNum";
            this.CoatsNum.Size = new System.Drawing.Size(68, 20);
            this.CoatsNum.TabIndex = 9;
            // 
            // CalcBtn
            // 
            this.CalcBtn.Location = new System.Drawing.Point(113, 146);
            this.CalcBtn.Name = "CalcBtn";
            this.CalcBtn.Size = new System.Drawing.Size(68, 25);
            this.CalcBtn.TabIndex = 10;
            this.CalcBtn.Text = "Calculate";
            this.CalcBtn.UseVisualStyleBackColor = true;
            this.CalcBtn.Click += new System.EventHandler(this.CalcBtn_Click);
            // 
            // MinGal
            // 
            this.MinGal.AutoSize = true;
            this.MinGal.Location = new System.Drawing.Point(245, 7);
            this.MinGal.Name = "MinGal";
            this.MinGal.Size = new System.Drawing.Size(87, 13);
            this.MinGal.TabIndex = 11;
            this.MinGal.Text = "Minimum gallons:";
            // 
            // GalToBuy
            // 
            this.GalToBuy.AutoSize = true;
            this.GalToBuy.Location = new System.Drawing.Point(245, 35);
            this.GalToBuy.Name = "GalToBuy";
            this.GalToBuy.Size = new System.Drawing.Size(104, 13);
            this.GalToBuy.TabIndex = 12;
            this.GalToBuy.Text = "Gallons to purchase:";
            // 
            // MinGalOut
            // 
            this.MinGalOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MinGalOut.Location = new System.Drawing.Point(370, 9);
            this.MinGalOut.Name = "MinGalOut";
            this.MinGalOut.Size = new System.Drawing.Size(62, 15);
            this.MinGalOut.TabIndex = 13;
            // 
            // GalToBuyOut
            // 
            this.GalToBuyOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.GalToBuyOut.Location = new System.Drawing.Point(370, 35);
            this.GalToBuyOut.Name = "GalToBuyOut";
            this.GalToBuyOut.Size = new System.Drawing.Size(62, 13);
            this.GalToBuyOut.TabIndex = 14;
            // 
            // Program1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 196);
            this.Controls.Add(this.GalToBuyOut);
            this.Controls.Add(this.MinGalOut);
            this.Controls.Add(this.GalToBuy);
            this.Controls.Add(this.MinGal);
            this.Controls.Add(this.CalcBtn);
            this.Controls.Add(this.CoatsNum);
            this.Controls.Add(this.PerimeterNum);
            this.Controls.Add(this.HeightNum);
            this.Controls.Add(this.DoorsNum);
            this.Controls.Add(this.WindowsNum);
            this.Controls.Add(this.CoatsLabel);
            this.Controls.Add(this.WindowsLabel);
            this.Controls.Add(this.DoorsLabel);
            this.Controls.Add(this.HeightLabel);
            this.Controls.Add(this.PerimeterLabel);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Program1";
            this.Text = "Paint Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PerimeterLabel;
        private System.Windows.Forms.Label HeightLabel;
        private System.Windows.Forms.Label DoorsLabel;
        private System.Windows.Forms.Label WindowsLabel;
        private System.Windows.Forms.Label CoatsLabel;
        private System.Windows.Forms.TextBox WindowsNum;
        private System.Windows.Forms.TextBox DoorsNum;
        private System.Windows.Forms.TextBox HeightNum;
        private System.Windows.Forms.TextBox PerimeterNum;
        private System.Windows.Forms.TextBox CoatsNum;
        private System.Windows.Forms.Button CalcBtn;
        private System.Windows.Forms.Label MinGal;
        private System.Windows.Forms.Label GalToBuy;
        private System.Windows.Forms.Label MinGalOut;
        private System.Windows.Forms.Label GalToBuyOut;
    }
}

