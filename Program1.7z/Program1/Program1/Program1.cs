﻿//User ID: J1559
//Program 1
//Due: 09/24/2019
//CIS 199-01
//Program calculates the number of gallons of paint needed to paint a room when user enters the dimensions, number of doors and windows, and coats of paint
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Program1 : Form
    {
        public Program1()
        {
            InitializeComponent();
        }
        //Activates once user clicks Calculate button
        private void CalcBtn_Click(object sender, EventArgs e)
        {
            const double GalSurfaceArea = 400; //constant for square footage per gallon
            const int DoorSA = 21; //constant for square footage per door
            const int WindowSA = 12; //constant for square footage per window
            double SurfaceArea; //total surface area of room
            double MinGal; //minimum number of gallons of paint required
            double Perimeter; //perimeter of room
            double Height; //height of room
            double GalToBuy; //number of gallons to buy
            int Doors; //number of doors
            int Windows; //number of windows
            int Coats; //number of coats of paint

            //input data from user entered data in text boxes
            Perimeter = double.Parse(PerimeterNum.Text);
            Height = double.Parse(HeightNum.Text);
            Doors = int.Parse(DoorsNum.Text);
            Windows = int.Parse(WindowsNum.Text);
            Coats = int.Parse(CoatsNum.Text);

            //arithmetic
            SurfaceArea = (Perimeter * Height - (Doors * DoorSA) - (Windows * WindowSA)) * Coats;
            MinGal = SurfaceArea / GalSurfaceArea;
            GalToBuy = (int)Math.Ceiling(MinGal);

            //output computed data to labels
            MinGalOut.Text = $"{MinGal:F1}";
            GalToBuyOut.Text = $"{GalToBuy}";

            
        }
    }
}
